CKEDITOR.plugins.setLang( 'bootstrapTabs', 'ru', {
  dialogTitle: 'Вкладки',
  invalidTabSetTitle: 'Название не может быть пустым.',
  invalidNumberOfTabs: 'Кол-во вкладок не может быть пустым.',
  tabBasicLabel: 'Основные настройки',
  infoHtml: '<p>Если вы хотите разбить содержимое на несколько частей - используйте вкладки для более эффективного использования пространства.<p>',
  tabSetTitleLabel: 'Название',
  numberOfTabsLabel: 'Количество вкладок',
  removeTabLabel: 'Удалить вкладку',
  removeTabDefault: 'Выберите удаляемую вкладку',
  buttonLabel: 'Вставить вкладки',
  contextMenuLabel:'Редактировать вкладки'
});
